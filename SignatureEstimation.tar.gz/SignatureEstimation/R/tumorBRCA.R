#' Proportions of 96 mutation types in 560 patients.
#'
#' A dataset containing the proportions of 96 mutation
#' subtypes in 560 breast cancer patients.
#'
#' @docType data
#'
#' @usage data(tumorBRCA)
#' @format A data frame with 96 rows and 560 columns:
#' \describe{
#'   \item{A[C>A]A}{the proportion of C mutates to A in the context of ACA in each patient}
#'   \item{PD10010}{Patient ID}
#'   ...
#' }
#' @source none
#' @examples
#' data(tumorBRCA)
NULL
