#' Proportions of 96 mutation types in 30 signatures.
#'
#' A dataset containing the proportions of 96 mutation
#' subtypes in 30 sigatures that are recorded by COSMIC.
#' @docType data
#'
#' @usage data(signaturesCOSMIC)
#' @format A data frame with 96 rows and 30 columns:
#' \describe{
#'   \item{A[C>A]A}{the proportion of C mutates to A in the context of A.A in each signature}
#'   \item{Signature 1}{Signature ID}
#'   ...
#' }
#' @source \url{http://cancer.sanger.ac.uk/cancergenome/assets/signatures_probabilities.txt}
#' @examples
#' data(signaturesCOSMIC)
NULL
