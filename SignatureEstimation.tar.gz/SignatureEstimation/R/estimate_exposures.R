
#' findSigExposures Function
#' wrapper function
#' This function allows to obtain the optimal solution by specifying quadratic programming or simulated annealing to solve the optimization problem.
#' @param M observed turmor profile matrix for all the patient/sample, 96 by G. G is the number of patients. Each column can be mutation
#' counts, or mutation probabilities. Each column will be normalized to sum up to 1.
#' @param P signature profile matrix, 96 by N(N = # signatures, COSMIC: N=30)
#' @param decompostion.method which method is selected to get the optimal solution: decomposeQP or decomposeSA
#' @keywords optimal method: QP or SA
#' @export
#' @examples
#' E1 = findSigExposures(tumorBRCA, signaturesCOSMIC, decomposeQP)
#' sigsBRCA = c(1,2,3,5,6,8,13,17,18,20,26,30)
#' E2 = findSigExposures(tumorBRCA, signaturesCOSMIC[, sigsBRCA], decomposeQP)
#' E3 = findSigExposures(tumorBRCA[, 1:10], signaturesCOSMIC, decomposeSA, list(maxit=1000, temperature=100))
#' E4 = findSigExposures(tumorBRCA[, 1:10], signaturesCOSMIC[, sigsBRCA], decomposeSA, list(maxit=2000))
#' E5 = findSigExposures(round(tumorBRCA*10000), signaturesCOSMIC, decomposeQP)

findSigExposures <- function(M, P, decomposition.method = decomposeQP, ...) {
  ## process and check function parameters
  ## M, P
  M = as.matrix(M)
  P = as.matrix(P)
  if(nrow(M) != nrow(P))
    stop("Matrices 'M' and 'P' must have the same number of rows (mutations types).")
  if(any(rownames(M) != rownames(P)))
    stop("Matrices 'M' and 'P' must have the same row names (mutations types).")
  if(ncol(P) == 1)
    stop("Matrices 'P' must have at least 2 columns (signatures).")
  ## decomposition.method
  if(!is.function(decomposition.method))
    stop("Parameter 'decomposition.method' must be a function.")
  ## normalize M by column (just in case it is not normalized)
  M = apply(M, 2, function(x){x/sum(x)})

  ## find solutions
  ## matrix of signature exposures per sample/patient (column)
  exposures = apply(M, 2, decomposition.method, P, ...)
  rownames(exposures) = colnames(P)
  colnames(exposures) = colnames(M)

  ## compute estimation error for each sample/patient (Frobenius norm)
  errors = sapply(seq(ncol(M)), function(i) FrobeniusNorm(M[,i],P,exposures[,i]))
  names(errors) = colnames(M)

  return(list(exposures=exposures, errors=errors))
}



#' bootstrapSigExposures Function
#' This function allows to obtain the bootstrap distribution of the signature exposures of a certain tumor sample
#' @param m observed turmor profile vector for a patient/sample, 96 by 1. It can be mutation
#' counts, or mutation probabilities.
#' @param P signature profile matrix, 96 by N (N = # signatures, COSMIC: N=30).
#' @param mutation.count if m is a vector of counts, then mutation.count equals the summation of all the counts.
#'  If m is probabilities, then mutation.count has to be specified.
#' @param R The number of bootstrap replicates.
#' @param decompostion.method which method is selected to get the optimal solution: decomposeQP or decomposeSA
#' @keywords bootstrap
#' @export
#' @examples
#' bootstrapSigExposures(tumorBRCA[,1], signaturesCOSMIC, 100, 2000, decomposeQP)
#' sigsBRCA = c(1,2,3,5,6,8,13,17,18,20,26,30)
#' bootstrapSigExposures(tumorBRCA[,1], signaturesCOSMIC[,sigsBRCA], 10, 1000, decomposeQP)

bootstrapSigExposures <- function(m, P, R, mutation.count = NULL, decomposition.method = decomposeQP, ...) {
  ## process and check function parameters
  ## m, P
  P = as.matrix(P)
  if(length(m) != nrow(P))
    stop("Length of vector 'm' and number of rows of matrix 'P' must be the same.")
  if(any(names(m) != rownames(P)))
    stop("Elements of vector 'm' and rows of matrix 'P' must have the same names (mutations types).")
  if(ncol(P) == 1)
    stop("Matrices 'P' must have at least 2 columns (signatures).")

  ## if 'mutation.count' is not specified the 'm' has to contain counts
  if(is.null(mutation.count)) {
    if(all(is.wholenumber(m))) # alternative test might be (assuming only 2 possibilities): sum(m) > 1
      mutation.count = sum(m)
    else
      stop("Please specify the parameter 'mutation.count' in the function call or provide mutation counts in parameter 'm'.")
  }

  ## normalize m to be a vector of probabilities.
  m = m / sum(m)

  ## find optimal solutions using using provided decomposition method for each bootstrap replicate
  ## matrix of signature exposures per replicate (column)
  K = length(m) #number of mutation types
  exposures = replicate(R, {
      mutations_sampled = sample(seq(K), mutation.count, replace = TRUE, prob = m)
      m_sampled = as.numeric(table(factor(mutations_sampled, levels=seq(K))))
      m_sampled = m_sampled / sum(m_sampled)
      decomposition.method(m_sampled, P, ...)
    })
  rownames(exposures) = colnames(P)
  colnames(exposures) = paste0('Replicate_',seq(R))

  ## compute estimation error for each replicate/trial (Frobenius norm)
  errors = apply(exposures, 2, function(e) FrobeniusNorm(m,P,e))
  names(errors) = colnames(exposures)

  return(list(exposures=exposures, errors=errors))
}



#' suboptimalSigExposures Function
#' This function allows to obtain the simulated annealing distribution of the signature exposures of a certain tumor sample
#' @param m observed turmor profile vector for a patient/sample, 96 by 1. It can be mutation
#' counts, or mutation probabilities.
#' @param P signature profile matrix, 96 by N(N = # signatures, COSMIC: N=30)
#' @param mutation.count if m is a vector of counts, then mutation.count equals the summation of all the counts.
#'  If m is probabilities, then mutation.count has to be specified.
#' @param R The number of replicates/trials of simulated annealing.
#' @param optimal.error if it is NULL, then use SA method to obtain. Or you can provide one.
#' @param suboptimal.factor suboptimal error.
#' @param control some control parameter that can be passed into the function
#' @keywords suboptimal 'simulated annealing'
#' @export
#' @examples
#' suboptimalSigExposures(tumorBRCA[,1], signaturesCOSMIC, 100, optimal.error = NULL, 1.05)

suboptimalSigExposures <- function(m, P, R, optimal.error = NULL, suboptimal.factor = 1.05, control = list()) {
  ## process and check function parameters
  ## m, P
  P = as.matrix(P)
  if(length(m) != nrow(P))
    stop("Length of vector 'm' and number of rows of matrix 'P' must be the same.")
  if(any(names(m) != rownames(P)))
    stop("Elements of vector 'm' and rows of matrix 'P' must have the same names (mutations types).")
  if(ncol(P) == 1)
    stop("Matrices 'P' must have at least 2 columns (signatures).")

  ## normalize m to be a vector of probabilities.
  m = m/sum(m)

  ## If optimal.error is null, we compute it by default SA method ('decomposeSA').
  if(is.null(optimal.error)) {
    sa_expos = decomposeSA(m, P, control)
    optimal.error = FrobeniusNorm(m, P, sa_expos)
  }

  ## find suboptimal solutions using simulated annealing with predefined error (with respect to optimal error)
  control$threshold.stop = suboptimal.factor * optimal.error
  ## matrix of signature exposures per replicate/trial (column)
  exposures = replicate(R, decomposeSA(m, P, control))
  rownames(exposures) = colnames(P)
  colnames(exposures) = paste0('Replicate_',seq(R))

  ## compute estimation error for each replicate/trial (Frobenius norm)
  errors = apply(exposures, 2, function(e) FrobeniusNorm(m,P,e))
  names(errors) = colnames(exposures)

  return(list(exposures=exposures, errors=errors))
}

